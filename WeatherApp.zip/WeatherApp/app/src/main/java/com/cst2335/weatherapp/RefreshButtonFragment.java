package com.cst2335.weatherapp;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

public class RefreshButtonFragment extends Fragment {
    private OnRefreshButtonClickListener listener;

    public interface OnRefreshButtonClickListener {
        void onRefreshButtonClick();
    }

    public RefreshButtonFragment() {
        // Required empty public constructor
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_refresh_button, container, false);
        Button refreshButton = view.findViewById(R.id.button_refresh);
        refreshButton.setOnClickListener(v -> {
            if (listener != null) {
                listener.onRefreshButtonClick();
            }
        });
        return view;
    }

    public void onAttach(@NonNull FragmentActivity activity) {
        super.onAttach(activity);
        if (activity instanceof OnRefreshButtonClickListener) {
            listener = (OnRefreshButtonClickListener) activity;
        }
    }
}
