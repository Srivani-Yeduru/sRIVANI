package com.cst2335.weatherapp;

import android.os.AsyncTask;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class MainActivity extends AppCompatActivity implements RefreshButtonFragment.OnRefreshButtonClickListener {
    private WeatherFragment weatherFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        weatherFragment = new WeatherFragment();
        RefreshButtonFragment refreshButtonFragment = new RefreshButtonFragment();

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.fragment_container, weatherFragment);
        fragmentTransaction.add(R.id.fragment_container, refreshButtonFragment);
        fragmentTransaction.commit();
    }

    @Override
    public void onRefreshButtonClick() {
        new FetchWeatherTask().execute();
    }

    private class FetchWeatherTask extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... voids) {
            // Perform network request to fetch weather data here
            // For simplicity, returning a dummy weather data
            return "Sunny, 25°C"; // Replace with actual API call
        }

        @Override
        protected void onPostExecute(String result) {
            weatherFragment.updateWeatherData(result);
        }
    }
}
